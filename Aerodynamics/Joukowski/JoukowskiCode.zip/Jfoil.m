classdef Jfoil
   properties
       angle
       cx
       cy
   end
   
   methods
       function obj = Jfoil(aoa,cx,cy) %Constructor
           %disp(aoa);
           obj.angle = aoa;
           obj.cx = cx;
           obj.cy = cy;
       end 
       
       function cl = surfaceRun(obj)
          %% Geometry Creation 
            % This makes the Circle
            N = 1000; 
            scaleFactor = 10;
            Cx = obj.cx;
            Cy = obj.cy;

            Cx = Cx/scaleFactor;
            Cy = Cy/scaleFactor;
            Center = Cx + Cy*1i;
            P1 = complex(1);

            R = abs(Center - P1);

            thetas = linspace(0,2*pi,N);

            circle = Center + R*exp(1i.*thetas);

            %This Makes the Airfoil
            airfoil = jMap(circle);
            P2 = complex(1);
            % Find maximum y value, double to find thickness since we have symmetric
            % airfoil:
            maxX = 0;
            minX = 0;
            
            thickness = 0;
            camber = 0;
           
             for(k = 1:numel(airfoil))
%                 if(imag(airfoil(k))>maxY)
%                     maxY = imag(airfoil(k)); 
%                 end
% 
%                 if(imag(airfoil(k))<minY)
%                     minY = imag(airfoil(k)); 
%                 end
%                 
                thick = imag(airfoil(k)) - imag(airfoil(N-k+1)); 
                
                if(thick > thickness)
                    thickness = thick;
                end
                
                camb = (imag(airfoil(k))+imag(airfoil(N-k+1)))/2;
                if(camb > camber)
                    camber = camb;
                end
                
                if(real(airfoil(k))>maxX)
                    maxX = real(airfoil(k));
                end

                if(real(airfoil(k))<minX)
                    minX = real(airfoil(k));
                end
             end

            %This is to make sure we are answering the real question
            chordLength = maxX-minX;
            %These are used just to make sure airfoil is valid
            thickPercent = thickness*100/chordLength;
            cambPercent = camber*100/chordLength; 


            %% Flow Parameters
            V = 10;

            aoa = obj.angle; % Degress
            aoa = deg2rad(aoa);

            Circ = 4*pi*V*R*sin(aoa+asin(Cy/R));

             position = circle;

             temp1 = V*exp(-1i*aoa);
             temp2 = 1i*Circ./(2*pi*(position - Center));
             temp3num = -V*R*R*exp(1i*aoa);
             temp3denom = (position - Center).*(position-Center);
             temp3 = temp3num./temp3denom;

             velocity = temp1 + temp2 + temp3;
             velocity = conj(velocity);
            
             %% Graphs
             % First some formatting and pre-processing
            %figure;
            %hold on;
            %axis([-5 5 -5 5]);
            [airMap,airVel] = jMapVel(position,velocity);
            velocityMags = abs(airVel);
            
            upperSurface = airMap(1:round(N/2));
            upperVels = velocityMags(1:round(N/2));
            
            lowerSurface = airMap(round(N/2):N);
            lowerVels = velocityMags(round(N/2):N);

            
            %Visual plot of Airfoil
            %plot(upperSurface,'r--');
            %plot(lowerSurface,'b--');
            
            figure;
            aoastr = num2str(rad2deg(aoa));
            camstr = num2str(cambPercent);
            tit = strcat('Pressure Gradient - Angle of Attack = ',aoastr,' Camber = ',camstr,'%');
            title(tit);
            xlabel('Position Along Chord')
            ylabel('Cp');
            
            hold on;
            CpUpper = 1-(upperVels/V).^2;
            CpLower = 1- (lowerVels/V).^2;
 

            plot(real(upperSurface),CpUpper,'r-');

            plot(real(lowerSurface),CpLower,'b-');
            
            legend('Upper Surface','Lower Surface', 'Location','southeast');
            
            % Kutta Joukowsky Theorem to calculate lift coefficient.
            kuttaLift = 1.2*V*Circ;
            q = .5*1.2*V^2;
            cl = kuttaLift/(q*chordLength);
              %% Helper Functions
            function w = jMap(z)
                w = z+1./z;
            end

            function [w,airVel] = jMapVel(z,v)
                w = z+1./z;

                v = conj(v);
                denom = 1-1./(z.*z);
                ret = v./denom;

                airVel = conj(ret);
            end
       end
   end
end