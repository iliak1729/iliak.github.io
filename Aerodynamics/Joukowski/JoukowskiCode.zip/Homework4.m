%% Symmetric Airfoil
clear,clc;


cx1 = -1.02021;%cx = -1.02021,cy= 0 for 12% Thick Symmetric Airfoil
cy1 = 0;


J1 = Jfoil(0,cx1, cy1);
J2 = Jfoil(5,cx1, cy1);
aoa2 = deg2rad(5);
J3 = Jfoil(10,cx1, cy1);
aoa3 = deg2rad(10);
J4 = Jfoil(15,cx1, cy1);
aoa4 = deg2rad(15);

%0,-1.01363,.43961 for 12% Thick 2% Camber Airfoil
cl1 = J1.surfaceRun();
cl2 = J2.surfaceRun();
cl3 = J3.surfaceRun();
cl4 = J4.surfaceRun();

% Take average slope from each case
m1 = (cl2-cl1)/aoa2;
m2 = (cl3-cl1)/aoa3;
m3 = (cl4-cl1)/aoa4;
m4 = (cl3-cl2)/(aoa3-aoa2);
m5 = (cl4-cl2)/(aoa4-aoa2);
m6 = (cl4-cl3)/(aoa4-aoa3);

averageM = m1+m2+m3+m4+m5+m6;
averageM1 = averageM/6;

noCamSet = [cl1,cl2,cl3,cl4];
%% Cambered Airfoil
cx1 = -1.01363;%cx = -1.01363, cy= .43961 for 12% Thick 2% Camber Airfoil
cy1 = .4397;


J5 = Jfoil(0,cx1, cy1);
aoa1 = 0;
J6 = Jfoil(5,cx1, cy1);
aoa2 = deg2rad(5);
J7 = Jfoil(10,cx1, cy1);
aoa3 = deg2rad(10);
J8 = Jfoil(15,cx1, cy1);
aoa4 = deg2rad(15);


cl1 = J5.surfaceRun();
cl2 = J6.surfaceRun();
cl3 = J7.surfaceRun();
cl4 = J8.surfaceRun();

% Take average slope from each case
m1 = (cl2-cl1)/aoa2;
m2 = (cl3-cl1)/aoa3;
m3 = (cl4-cl1)/aoa4;
m4 = (cl3-cl2)/(aoa3-aoa2);
m5 = (cl4-cl2)/(aoa4-aoa2);
m6 = (cl4-cl3)/(aoa4-aoa3);

averageM = m1+m2+m3+m4+m5+m6;
averageM2 = averageM/6;

camSet = [cl1,cl2,cl3,cl4];

%% Cl-aoa Slope Comparison

%Here,we will plot the lift coefficient to the angle of attack. We also
%plotted the theory curve in each case to see our variation from each.
xset = linspace(0,15,4);
xset = deg2rad(xset);
yset = 2*pi*xset;

figure;
NACAaoa = [0.038772741,2.05982177,6.01864536,9.932239783,14.16254093,...
    14.36464087, 17.98442351,22.07932961,26.01753869,27.87918097,...
    31.99647093];
NACAaoa = deg2rad(NACAaoa);
NACAcl = [0.00652805,.22331494,.62902511,1.03258364,1.30984164,...
    1.00359647,.83948681,.70332889,.85200745,.91454208,...
    1.00542989];
hold on;
title('Symmetric Cl v AOA Curve');
plot(xset,noCamSet,'r-');
plot(xset,yset,'b-');
plot(NACAaoa,NACAcl,'k-')
xlabel('Angle of Attack');
ylabel('cl');
legend('Code','Theory','NACA-0012', 'Location','southeast');

yset = yset+cl1;
figure;
hold on;
title('Cambered Cl v AOA Curve');
plot(xset,camSet,'r-');
plot(xset,yset,'b-');
plot(NACAaoa,NACAcl,'k-')
xlabel('Angle of Attack');
ylabel('cl');
legend('Code','Theory','NACA-0012', 'Location','southeast');


disp('Slope of Cl-aoa line, 0% Camber');
disp(averageM1);

disp('Slope of Cl-aoa line, 2% Camber');
disp(averageM2);

%% Reflection
% At this point, we can see some of the power that comes with the joukowski
% transform. The results given were fairly accurate. Although we did not
% see exactly a slope of 2*pi, our results were very close to this value.
% The error here likely results from several different sources. The first
% that somes to my mind is viscous effects. Next, we should notice that we
% made small angle approximations in our derivation of some of the theorems
% about. Additonal, we should notice that Joukowsky airfoils are also not
% perfectly physical as a cusp forms at the trailing edge. Additionally,
% our potentially flow assumptions add another layer of error. Together,
% these effects work to change our lift, more often dissipating lift than
% agumenting it. As such, our slope discrepency of .5 is likely due to
% these effects.

% A effect of notice here is the little spike at the end of symmetric
% graphs. I believe that this is a result of the kutta condition creating a
% stagnation point at the trailing edge. However, since we had to
% discritize our system the Cp 1 zone near these occurs very quickly. I
% believe if we zoom in on that area and refine the mesh, we would see a
% smooth but steep transition. 