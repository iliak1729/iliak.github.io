classdef Wing
    %UNTITLED2 Summary of this class goes here
    %   Detailed explanation goes here

    properties
        lgt;
        aoa;
        liftingLine;
        convergenceCount;
    end
    
    methods(Static)
        function circ = ellipticLift(y,b,cMax)
            circ = cMax*sqrt(1-(2*y/b).^2);
        end

   end
    
    methods
        %Constructor
        function obj = Wing(L,aoa,foil,N,chord)
           obj.lgt = L;
           obj.aoa = aoa;
           yset = linspace(-L/2,L/2,N+1);
%            gamma0 = 2*51.44*chord*.8773/pi;
            gamma0 = 1;
           disp(gamma0)
           for i = 1:N
               midpoint = (yset(i)+yset(i+1))/2;
               circ = Wing.ellipticLift(midpoint,L,gamma0);
               line(i) = Horseshoe(yset(i),yset(i+1),circ,aoa,chord,foil);
           end
            
           obj.liftingLine = line;

           obj.convergenceCount = 0;
        end
        
        % Functional Methods
        function [strengths,locs] = trailStrengths(obj) 
            % This function has passed its tests. It is working. I am
            % confident
            strengths = zeros(1,length(obj.liftingLine)+1);
            locs = zeros(size(strengths));

            strengths(1) = obj.liftingLine(1).getStrength();
            strengths(end) = -obj.liftingLine(end).getStrength();
            locs(1) = obj.liftingLine(1).getLeftPoint();
            locs(end) = obj.liftingLine(end).getRightPoint();

            for i = 2:(length(strengths)-1)
                strengths(i) = obj.liftingLine(i).getStrength() - ...
                    obj.liftingLine(i-1).getStrength();
                locs(i) = obj.liftingLine(i).getLeftPoint();
            end
        end
        
        function vin = inducedVelocity(obj,y)
            % No it isn't
            vin = 0;
            [strSet,trailLocations] = obj.trailStrengths();

            for i = 1:length(strSet)
                denom = 4.*pi.*(y-trailLocations(i));
                absAdd = strSet(i)./denom;
                vin = vin - absAdd;
            end
        end

        function ai = inducedAOA(obj,y,vinf)
            vin = obj.inducedVelocity(y);
            ai = atan(-vin./vinf);
            ai = rad2deg(ai);
        end

        function circNew = calcCircNew(obj,freestream,T)
            circNew = zeros(size(obj.liftingLine));
            for i = 1:length(obj.liftingLine)
                lineCurr = obj.liftingLine(i);
                controlPoint = lineCurr.getMidpoint();
                aGeo = lineCurr.getAlphaGeo();

                ai = obj.inducedAOA(controlPoint,freestream(controlPoint,T));
                aeff = aGeo - ai;
                
                cl = lineCurr.getClStatic(aeff);
                circNew(i) = .5*cl*freestream(controlPoint,T)*lineCurr.getChord();
            end
        end

        function [obj,convBool] = updateCirc(obj, circNew,gain, conv)
            avrgDelta = 0;
            for i = 1:length(circNew)
                circTemp = circNew(i);
                horseCurr = obj.liftingLine(i);
                circOld = horseCurr.getStrength();

                delta = circTemp - circOld;
                avrgDelta = avrgDelta + delta;

                circSet = circOld + gain*delta;
                
                obj.liftingLine(i) = horseCurr.setStrength(circSet);
            end
            avrgDelta = avrgDelta/(length(circNew));
            convBool = false;
            if(avrgDelta < conv)
                obj.convergenceCount = obj.convergenceCount + 1;
                if(obj.convergenceCount > 5)
                    convBool = true;
                end
            else
                obj.convergenceCount = 0;
            end
        end


        % Draw method for checking
        function draw(obj)
            hold on;
            for i = 1:length(obj.liftingLine)
                obj.liftingLine(i).draw();
            end
        end
       
        function liftDistro(obj)
            hold on;
            xset = zeros(length(obj.liftingLine));
            yset = zeros(length(obj.liftingLine));
            for i = 1:length(obj.liftingLine)
                xset(i) = obj.liftingLine(i).getMidpoint();
                yset(i) = obj.liftingLine(i).getStrength();
            end
            plot(xset,yset,'r-');
        end
        % Getters
        function ret = getControlPoints(obj)
            ret = zeros(size(obj.liftingLine));
            for i = 1:length(ret)
                ret(i) = obj.liftingLine(i).getMidpoint();
            end
        end
    end
    
    

end