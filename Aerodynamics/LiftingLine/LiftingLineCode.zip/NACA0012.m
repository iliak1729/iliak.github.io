classdef NACA0012
    % This class is the NACA 0012 airfoil data imbedded into a class with
    % some methods.
    % The reason I am using an entire class to generate this
    % distinction is in the hopes of making this program scalable. By
    % making distinct airfoil classes that can all be accepted by the
    % Horseshoe class, the primary roadblock to having different airfoils
    % will just be how many classes I can create.
    properties
    end

    methods(Static)
        function cl = liftCoefficientDeg(aoa)
            sampleAlpha = [-2.025902479,.038772741,2.05982177,6.017645346,...
                9.932239783,14.16254093,14.36464087,17.98442351,...
                22.07932961,26.01754869,27.87918097,31.99647093];

            sampleCl = [-.20812679,.00652805,.22331494,.62902511,...
                1.03258364,1.30984164,1.00359647,.83948681,...
                .70332889,.85200745,.91454208,1.00542989];

            for i = 2:(length(sampleAlpha)-1)
                % disp(i)
                if(aoa < sampleAlpha(1))
                    % disp('first');
                    slope = (sampleCl(1)-sampleCl(2))/(sampleAlpha(1)-sampleAlpha(2));
                    cl = slope*(aoa-sampleAlpha(1))+sampleCl(1);
                    break
                elseif(aoa > sampleAlpha(end))
                    % disp('second');
                    slope = (sampleCl(end)-sampleCl(end-1))/(sampleAlpha(end)-sampleAlpha(end-1));
                    cl = slope*(aoa-sampleAlpha(end))+sampleCl(end);
                    break
                elseif(aoa < sampleAlpha(i))
                    % disp('third');
                    slope = (sampleCl(i)-sampleCl(i-1))/(sampleAlpha(i)-sampleAlpha(i-1));
                    cl = slope*(aoa-sampleAlpha(i))+sampleCl(i);
                    break
                end
            end
        end

        function cl = dragCoefficientDeg(aoa)
            sampleAlpha = [-2.08998,1.992422,5.944141,10.02674,14.36712,...
                14.96876,16.05107,18.04577,20.03113,21.982,26.01005,...
                28.08664,31.939];

            sampleCd = [.014616,.013394,.016427,.013064,.039745,...
                .108421,.145077,.177656,.310901,.347753,.464323,...
                .550467,.688417];

            for i = 2:(length(sampleAlpha)-1)
                if(aoa < sampleAlpha(1))
                    slope = (sampleCd(1)-sampleCd(2))/(sampleAlpha(1)-sampleAlpha(2));
                    cl = slope*(aoa-sampleAlpha(1))+sampleCd(1);
                elseif(aoa > sampleAlpha(end))
                    slope = (sampleCd(end)-sampleCd(end-1))/(sampleAlpha(end)-sampleAlpha(end-1));
                    cl = slope*(aoa-sampleAlpha(end))+sampleCd(end);
                elseif(aoa < sampleAlpha(i))
                    slope = (sampleCd(i)-sampleCd(i-1))/(sampleAlpha(i)-sampleAlpha(i-1));
                    cl = slope*(aoa-sampleAlpha(i))+sampleCd(i);
                end
            end
        end


    end
end