classdef Horseshoe
    % This is a horseshoe vortex class. The foundations of both prandtl
    % lifting line and numeric lifting line is this construct. Here, we
    % represent it as a 1D object defined by the endpoints and the
    % strength. We will sequence them together to create a wing. This
    % grouping of Horseshoes is done by the 

    properties
        y1;
        y2;
        S;
        aoaGeo;
        aoaEff;
        airfoil;
        Vinf;
        chord;
    end

    methods
        function obj = Horseshoe(y1in,y2in,Sin,aoain,C,foil)
            obj.y1 = y1in; %start point
            obj.y2 = y2in; % end point
            obj.S = Sin; % strength
            obj.aoaGeo = aoain; % geometric angle of attack
            obj.aoaEff = aoain; % effective angle of attack
            obj.airfoil = foil;
            obj.chord = C;
        end

        function draw(obj)
            hold on;
            line([obj.y1 obj.y2],[0 0]);
            plot([obj.y1,obj.y2],[0,0],'k.');
            plot(obj.getMidpoint(),0,'rx');

        end
        % Getters and Setters
        function cl = getCl(obj)
            cl = obj.airfoil.liftCoefficientDeg(obj.aoaEff);
        end

        function cl = getClStatic(obj,aoa)
            cl = obj.airfoil.liftCoefficientDeg(aoa);
        end

        function y = getLeftPoint(obj)
            y = obj.y1;
        end

        function y = getRightPoint(obj)
            y = obj.y2;
        end

        function a = getAlphaGeo(obj)
            a = obj.aoaGeo;
        end

        function a = getAlphaEff(obj)
            a = obj.aoaEff;
        end

        function y = getMidpoint(obj)
            y = (obj.y1+obj.y2)/2;
        end
        
        function str = getStrength(obj)
            str = obj.S;
        end

        function C = getChord(obj)
            C = obj.chord;
        end

        function obj = setStrength(obj, nS)
            obj.S = nS;
        end

        function obj = setAlphaEff(obj, aNew)
            obj.aoaEff = aNew;
        end
    end
end