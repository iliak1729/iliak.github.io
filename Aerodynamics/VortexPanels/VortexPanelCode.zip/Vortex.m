% This class allows for the creation of a vortex at any given location. It
% will not be used directly in the main, but will be used to enable our
% VortexPanel class.

classdef Vortex
   properties
      x;
      y;
      comCen;
      S;
   end
   methods
       % Constructor
       function obj = Vortex(x,y,S) 
           obj.x = x;
           obj.y = y;
           obj.S = S;
           obj.comCen = complex(x+y*1i);
       end
       
       % Working Methods
       function v = velVec(obj,P)
           dP = P-obj.comCen;
           v = -1i*conj(obj.S./(2*pi*dP));
       end
       
       function [grid,v] = velField(obj,xmin,ymin,xmax,ymax,Nx,Ny)
           xSet = linspace(xmin,xmax,Nx);
           ySet = linspace(ymin,ymax,Ny);
           [xSet,ySet] = meshgrid(xSet,ySet);
           grid = xSet+ySet*1i;
           
           v = obj.velVec(grid);
       end

       % Setters

       % This setStrength method will be very important for the homework.
       % To create our ICM, we will create all our vortex panels with a
       % strength fo 1. We can then use a higher level function to get the
       % influence from each vortex panel at each colocation point. Once we
       % have solved for the ICM and found the true strengths, we then need
       % a way to set the strengths to their true values and this will
       % allow us to do that.
       function obj = setStrength(obj,nS) 
           obj.S = nS;
       end

       % Getters
       function ret = getX(obj)
           ret = obj.x;
       end

       function ret = getY(obj)
           ret = obj.y;
       end

       function ret = getStrength(obj)
           ret = obj.S;
       end

       function ret = getCenter(obj)
           ret = obj.comCen;
       end

   end
end