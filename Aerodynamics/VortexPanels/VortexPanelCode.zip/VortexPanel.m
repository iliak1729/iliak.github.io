  % This is is the primary class our main file will be interfacing with. It
% all the primary functions we expect out of a panel will be implemented in
% this file and will simply be called in our main file.

classdef VortexPanel
   properties
      p1;
      p2;
      Vortex;
      colocation;
   end
   methods(Static)
       function foil = meshFoil(xset, yset)
           N = length(xset)-1;
           for j = 1:N
               p1 = complex(xset(j)+yset(j)*1i);
               p2 = complex(xset(j+1)+yset(j+1)*1i);

               foil(j) = VortexPanel(p1,p2,1);
              % I know this is memory inefficient since I am not allocating space
              % I have to accept this because I don't know a better way.
              % Maybe I fix Later
           end
       end

       function [strengths,cl] = solve(foil,vinfty,Vmag,c,N,res)
           ICM = zeros(N);
           RHS = zeros(1,N);
           for i=1:length(foil) % Current Panel Vortex
               currVortexPanel = foil(i);
            
               for j = 1:length(foil) % Panel we will calculate influence on.
                   targetPanel = foil(j);
                
                   inducedVel = currVortexPanel.getInfluence(targetPanel.getColocationPoint());
                   normalVec = targetPanel.getDirVec()*1i;
                   ICM(i,j) = real(inducedVel)*real(normalVec)+imag(inducedVel)*imag(normalVec);
        
                   if(i==1)
                       RHS(j) = -real(vinfty)*real(normalVec)-imag(vinfty)*imag(normalVec);
                   end
               end
           end

           strengths = RHS/ICM;

           for i = 1:length(foil)
               foil(i) = foil(i).setStrength(strengths(i));
           end
        
        %Here Let us check the colocation points
           for i = 1:length(foil)
               colocPoint = complex(foil(i).getColocationPoint());
               vel = 0;
               for j = 1:length(foil)
                   vel = vel + foil(j).velVec(colocPoint);
               end
               vel = vel + vinfty;
               normalVec = foil(i).getDirVec()*1i;
        
               normalVel = real(vel)*real(normalVec)+imag(vel)*imag(normalVec);
               if(not(normalVel < res))
                   disp('Residues Not Met')
               end
           end

           totalCirc = 0;
           for i = 1:length(strengths)
               totalCirc = totalCirc + strengths(i);
           end
           
           rho = 1.2;

           L = rho*Vmag*totalCirc;
        
           q = .5*rho*Vmag^2;
        
           cl = L/(q*c);
           %disp(ICM);
       end
   end

   methods
       % Constructor
       function obj = VortexPanel(p1,p2,S)
           vorPoint = complex(p1+.25*(p2-p1));
           obj.colocation = complex(p1+.75*(p2-p1));
           obj.Vortex = Vortex(real(vorPoint),imag(vorPoint),S);
           obj.p1 = p1;
           obj.p2 = p2;
       end
       
       % Important Method
      

       function ret = getInfluence(obj,P)
           ret = obj.Vortex.velVec(P);
       end
        
       function [grid,v] = velField(obj,xmin,ymin,xmax,ymax,Nx,Ny)
           [grid,v] = obj.Vortex.velField(xmin,ymin,xmax,ymax,Nx,Ny);
       end

       function v = velVec(obj,P)
           v = obj.Vortex.velVec(P);
       end

       function draw(obj)
           line([real(obj.p1) real(obj.p2)],[imag(obj.p1) imag(obj.p2)]);
           plot(obj.p1,'k.');
           plot(obj.p2,'k.');
       end

       function simpleDraw(obj)
           line([real(obj.p1) real(obj.p2)],[imag(obj.p1) imag(obj.p2)]);
       end
       
       function detailDraw(obj)
           obj.draw();
           plot(obj.Vortex.getCenter(),'ro');
           plot(obj.colocation,'rx');
       end

       % Setters
       function obj = setStrength(obj,nS)
           obj.Vortex = obj.Vortex.setStrength(nS);
       end
        
       % Getters
       function ret = getDirVec(obj)
           ret = (obj.p2-obj.p1);
           ret = ret./abs(ret);

       end
       function ret = getColocationPoint(obj)
           ret = obj.colocation;
       end

       function ret = getVortexLocation(obj)
           ret = obj.Vortex.getCenter();
       end

       function ret = getP1(obj)
           ret = obj.p1;
       end

       function ret = getP2(obj)
           ret = obj.p2;
       end

       function ret = getStrength(obj)
           ret = obj.Vortex.getStrength();
       end

   end
end