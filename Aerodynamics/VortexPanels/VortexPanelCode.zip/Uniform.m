% This class is used to generate a freestream velocity that we can use in
% our main file. 
classdef Uniform
   properties
      dir;
      vMag;
      v;
   end
   methods
       % Constructor
       function obj = Uniform(vMag,dir) 
           obj.vMag = vMag;
           obj.dir = dir;
           obj.v = vMag*cosd(dir)+vMag*sind(dir)*1i;
       end
       
       % Working Methods
       function ret = velVec(obj,P)
           ret = zeros(size(P))+obj.v;
       end
       
       function [grid,v] = velField(obj,xmin,ymin,xmax,ymax,Nx,Ny)
           xSet = linspace(xmin,xmax,Nx);
           ySet = linspace(ymin,ymax,Ny);
           [xSet,ySet] = meshgrid(xSet,ySet);
           grid = xSet+ySet*1i;
           
           v = obj.velVec(grid);
       end

       % Setters

       % This setStrength method will be very important for the homework.
       % To create our ICM, we will create all our vortex panels with a
       % strength fo 1. We can then use a higher level function to get the
       % influence from each vortex panel at each colocation point. Once we
       % have solved for the ICM and found the true strengths, we then need
       % a way to set the strengths to their true values and this will
       % allow us to do that.
       function obj = setStrength(obj,vMag) 
           obj.vMag=vMag;
           obj.v = vMag*cosd(obj.dir)+vMag*sind(obj.dir)*1i;
       end

       % Getters
       function ret = getDir(obj)
           ret = obj.dir;
       end

       function ret = getVelocity(obj)
           ret = obj.v;
       end

       function ret = getSpeed(obj)
           ret = obj.vMag;
       end

   end
end