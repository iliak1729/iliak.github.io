% Using the NACA 4 Series equations, we can create a line airfoil using the
% mean camber line equation. This equation is robust enough to deal with
% any camber we would like, including none. Although not as useful for this
% homework, this equation also allows us to move the location of max camber
% if we would like.

function P = airfoil(x0,y0,angle,m,p,c,N)
    xset = linspace(0,c,N); % Make set of x coordinates ranging from 0 to 
    % end of chord
    yset = zeros(size(xset));
    % Allocate space for airfoil
    P = complex(zeros(size(N)));
    
    % Create airfoil at origin with proper geometry but zero angle
    for i=1:length(xset)
        xcurr = xset(i);
        if(xcurr<p*c)
            yset(i) = (m*c/p^2)*(2*xcurr*p/c-xcurr^2/c^2);
        else
            yset(i) = (m*c/(1-p)^2)*((1-2*p)+2*p*xcurr/c-xcurr^2/c^2);
        end

        P(i) = complex(xcurr + yset(i)*1i);
    end

    % These few lines now rotate the airfoil about the origin to the proper
    % angle. Remeber that this is with the CCW positive convention, so an
    % increasing angle of attack would be a negative angle here.
    angle = deg2rad(angle);
    rotVec = exp(angle*1i);

    P = P*rotVec;
    % Finally, we translate the airfoil to the proper location
    P = complex(P + x0);
    P = complex(P + y0*1i);
end