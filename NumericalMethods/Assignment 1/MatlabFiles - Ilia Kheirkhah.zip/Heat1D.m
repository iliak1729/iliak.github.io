%% Heat1D
% This function provides us with our heat equation matrix, b vector, and
% grid point locations.
function [A,b,x] = Heat1D(alpha,n,xmin,xmax,Txmin,Txmax)
    b = zeros(n+1,1)-alpha;
    h = (xmax - xmin)/n;
    b(1) = Txmin/h^2;
    b(end) = Txmax/h^2;
    x=xmin:h:xmax;

    A = zeros(n+1);
    for i = 1:(n+1)
        if(i==1 || i == n+1)
            A(i,i) = 1;
        else
            A(i,i-1) = 1;
            A(i,i) = -2;
            A(i,i+1) = 1;
        end
    end
    A = A./h^2;

end