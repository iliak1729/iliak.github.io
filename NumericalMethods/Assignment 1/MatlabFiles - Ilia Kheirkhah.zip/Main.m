%% Main File
% This is the file where we do all the problem solving.We have done 
% Problems 1 and 2. Our Solver is complete and we can make the
% discretized heat equation. Let us solve our other stuff.

%% Problem 3 - Numerical Solutions for the 1D and 2D BVP
% Here we solve the heat equation for alpha = 2 with various grid sizes.
% We graph our results and compare how they look.

% 1D solution
clear; clc; close all;
alpha = 2;
nset = [4,10,24,50,100];
fileTemplate = "1D_N=";
for i = 1:length(nset)
    N = nset(i);
    [A,b,x] = Heat1D(alpha,N,0,1,0,0);
    T = Ludecomp(A,b,N+1,10e-6,zeros(N+1,1));

    figure;
    hold on;
    plot(x,T,'r-');

    xlabel('Position (Length)')
    ylabel('Temperature (K)');
    title("1D Heat Equation --- N = "+num2str(N));
    xlim([0 1]);
    ylim([0 .25]);
    fileName  = fileTemplate + num2str(N)+".png";
    exportgraphics(gcf,fileName);
    
end

% 2D solution
nset2 = [5,10,25,50];
fileTemplate = "2D_N=";
for i = 1:length(nset2)
    N2 = nset2(i);
    [Aheat2,bheat2,x,y] = Heat2D(2,N2,0,1,0,1);
    tres = Ludecomp(Aheat2,bheat2,(N2+1)^2,10e-6,zeros((N2+1)^2,1));

    t2d = zeros(N2+1);
    res = zeros(length(tres),3);
    % Translate from l system to i,j system array
    for l = 1:length(tres)
        k = mod(l-1,N2+1)+1;
        j = (l-k)/(N2+1)+1;
        res(l,1)=l;
        res(l,2)=k;
        res(l,3)=j;
        t2d(k,j)=tres(l);
    end

    figure;
    contourf(x,y,t2d,20);
    colormap(flipud(hot));
    tempbar = colorbar;
    tempbar.Title.String = "Temperature (K)";
    xlabel('X-Position (Length)')
    ylabel('Y-Position (Length)');
    title("2D Heat Equation --- N = "+num2str(N2));

    fileName = fileTemplate + num2str(N2) + ".png";
    exportgraphics(gcf,fileName);
end

%% Problem 4 - Timing of Personal vs. Matlab LU Command
% Here we analyze how our implementation of LU decomposition compares
% against MATLAB's internal method. To compare, we will call our Ludecomp
% script and time it using the tic-toc functions of matlab. We will then
% find the solution by forcing matlab to use its LU function. This will
% allow us to compare our results. First we need to figure out how to force
% Matlab to call its LU solver instead of the banded solver. To do this, we
% will use the function we create at the end of this file.
% Given this function is implemented, we can vary the grid refinement from
% 50 to 2500 in increments of 50 to get a decent idea of the time trends.
% Our results follow.
clear;clc; close all;

%1D timing 
alpha = 2;
nset = 100:5:1000;
times = zeros(length(nset),2);
for i = 1:length(nset)
    N = nset(i);
    [A,b,~] = Heat1D(alpha,N,0,1,0,0);
    tic
    [~] = Ludecomp(A,b,N+1,10e-6,zeros(N+1,1));
    times(i,1) = toc;
    
    [~,times(i,2)] = forceLU(A,b);
end
matrixSizes = nset;
logSize = log10(matrixSizes);
logTimesMe = transpose(log10(times(:,1)));
logTimesMat = transpose(log10(times(:,2)));

p1 = polyfit(logSize,logTimesMe,1);
p2 = polyfit(logSize,logTimesMat,1);

fitTimeMe = (matrixSizes.^p1(1))*10.^(p1(2));
fitTimeMat = (matrixSizes.^p2(1))*10.^(p2(2));

figure;
loglog(nset,times(:,1),'r-');
hold on;
loglog(matrixSizes,fitTimeMe,'k-');
xlabel('Matrix Size ((N+1)');
ylabel('Time (s)');
title('Personal LU Timing for 1D BVP');
a = annotation('textbox',[.15 .58 .2 .2],'String',"y = "+num2str(p1(1))+"x + "+num2str(p1(2)),'FitBoxToText','on');
legend('Measured','Linear Fit','Location','northwest');
exportgraphics(gcf,"PersonalLU1D.png");

figure;
loglog(nset,times(:,2),'r-');
hold on;
loglog(matrixSizes,fitTimeMat,'k-');
xlabel('Matrix Size (N+1)');
ylabel('Time (s)');
title('Matlab LU Timing for 1D BVP');
a = annotation('textbox',[.15 .58 .2 .2],'String',"y = "+num2str(p2(1))+"x + "+num2str(p2(2)),'FitBoxToText','on');
legend('Measured','Linear Fit','Location','northwest');
exportgraphics(gcf,"MatlabLU1D.png");

%2D timing
nset = 5:1:50;
times = zeros(length(nset),2);
for i = 1:length(nset)
    N = nset(i);
    [A,b,~] = Heat2D(alpha,N,0,1,0,1);
    tic
    [~] = Ludecomp(A,b,(N+1).^2,10e-6,zeros((N+1).^2,1));
    times(i,1) = toc;
    
    [~,times(i,2)] = forceLU(A,b);
end
matrixSizes = (nset + 1).^2;
logSize = log10(matrixSizes);
logTimesMe = transpose(log10(times(:,1)));
logTimesMat = transpose(log10(times(:,2)));

p1 = polyfit(logSize,logTimesMe,1);
p2 = polyfit(logSize,logTimesMat,1);

fitTimeMe = (matrixSizes.^p1(1))*10.^(p1(2));
fitTimeMat = (matrixSizes.^p2(1))*10.^(p2(2));

figure;
loglog(matrixSizes,times(:,1),'r.-');
hold on;
loglog(matrixSizes,fitTimeMe,'k-');
xlabel('Matrix Size ((N+1)^{2})');
ylabel('Time (s)');
title('Personal LU Timing for 2D BVP');
a = annotation('textbox',[.15 .58 .2 .2],'String',"y = "+num2str(p1(1))+"x + "+num2str(p1(2)),'FitBoxToText','on');
legend('Measured','Linear Fit','Location','northwest');
exportgraphics(gcf,"PersonalLU2D.png");
figure;
loglog(matrixSizes,times(:,2),'r.-');
hold on;
loglog(matrixSizes,fitTimeMat,'k-');
xlabel('Matrix Size ((N+1)^{2})');
ylabel('Time (s)');
title('Matlab Intrinsic LU Timing for 2D BVP');
a = annotation('textbox',[.15 .58 .2 .2],'String',"y = "+num2str(p2(1))+"x + "+num2str(p2(2)),'FitBoxToText','on');
legend('Measured','Linear Fit','Location','northwest');
exportgraphics(gcf,"MatlabLU2D.png");

%% Problem 5 - Error
clear; clc; close all;

% Vary Grid Size, alpha = 2
%nset = [5,6,10,12,15,20,24,30,40,60];
nset = [2,3,5,6,10,12,20,24,30,40];
nref = 120;
alpha = 2;

[A,b,x,y] = Heat2D(alpha,nref,0,1,0,1);
Tref = A\b;
Tref2D = zeros(nref+1);

for l = 1:length(Tref)
    i = mod(l-1,nref+1)+1;
    j = (l-i)/(nref+1)+1;

    Tref2D(i,j)=Tref(l);
end

normalizedError1 = zeros(length(nset),1);
for i = 1:length(nset)
    [A,b,x,y] = Heat2D(alpha,nset(i),0,1,0,1);
    Tres = Ludecomp(A,b,(nset(i)+1)^2,10e-6,zeros((nset(i)+1)^2,1));
    Tres2D = zeros(nset(i)+1);
    for l = 1:length(Tres)
        k = mod(l-1,nset(i)+1)+1;
        j = (l-k)/(nset(i)+1)+1;

        Tres2D(k,j)=Tres(l);
    end
     errorArray = zeros(nset(i)+1);
     scaler = nref/nset(i);
     sum = 0;
     for j = 1:(nset(i)+1)
         for k = 1:(nset(i)+1)
             errorArray(j,k) = (Tres2D(j,k) - Tref2D(1+scaler*(j-1),1+scaler*(k-1))).^2;
             sum = sum + errorArray(j,k);
         end
     end
     sum = sqrt(sum);
     normalizedError1(i) = sum/((nset(i)+1));
end

logSize = log10(nset);
logError = log10(normalizedError1);

p1 = polyfit(logSize,logError,1);
fitLine =  (nset.^p1(1))*10.^(p1(2));

figure;
loglog(nset,normalizedError1,'b.-');
hold on;
plot(nset,fitLine,'k-');
title("Fit Line Error - \alpha = 2");
xlabel("Log Grid Size (log(n))");
ylabel("Log Average Error");
a = annotation('textbox',[.15 .12 .2 .2],'String',"y = "+num2str(p1(1)) ...
    +"x + "+num2str(p1(2)),'FitBoxToText','on');
legend('Measured','Linear Fit','Location','southwest');
exportgraphics(gcf,"ErrorFitGraph.png");

figure;
plot(nset,normalizedError1,'b.-');
title("Error Trend for \alpha = 2");
xlabel("Grid Size (n)");
ylabel("Average Error");
exportgraphics(gcf,"ErrorGraph.png");

% Vary Alpha Error
alphaSet = [2,5,10,25,50];
figure;
hold on;
for i = 1:length(alphaSet)
    alpha = alphaSet(i);
    normalizedError = zeros(length(nset),1);
    [A,b,x,y] = Heat2D(alpha,nref,0,1,0,1);
    Tref = A\b;
    Tref2D = zeros(nref+1);

    for l = 1:length(Tref)
        k = mod(l-1,nref+1)+1;
        j = (l-k)/(nref+1)+1;

        Tref2D(k,j)=Tref(l);
    end

    for j = 1:length(nset)
        [A,b,~] = Heat2D(alpha,nset(j),0,1,0,1);
        Tres = Ludecomp(A,b,(nset(j)+1)^2,10e-6,zeros((nset(j)+1)^2,1));
        
        Tres2D = zeros(nset(j)+1);
        for l = 1:length(Tres)
            k = mod(l-1,nset(j)+1)+1;
            m = (l-k)/(nset(j)+1)+1;

            Tres2D(k,m)=Tres(l);
        end
        errorArray = zeros(size(Tres2D));
        scaler = nref/nset(j);
        sum = 0;
        for k = 1:(nset(j)+1)
            for m = 1:(nset(j)+1)
                errorArray(k,m) = Tres2D(k,m) - ...
                    Tref2D(1+scaler*(k-1),1+scaler*(m-1));
                errorArray(k,m) = errorArray(k,m).^2;
                sum = sum + errorArray(k,m);
            end
        end
        sum = sqrt(sum);
        normalizedError(j,1) = sum/(nset(j)+1);
        disp(num2str(nset(j))+"donef");
    end
    plot(nset,normalizedError,'.-','DisplayName',"$\alpha$ = "+num2str(alpha));
    title('Error vs Grid Size for Various \alpha');
    xlabel('Grid Size (n)');
    ylabel('Average Error');
end

legend('Interpreter','latex');

exportgraphics(gcf,"AlphaError.png");
%% Helper Functions

function [res,time] = forceLU(A,b)
    tic
    [L,U,P] = lu(A);
    y = L\(P*b);
    res = U\y;
    time = toc;
end