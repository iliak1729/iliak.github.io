%% Ludecomp Function
% This function is the primary working function that we will make use of.
% Although it does very little in itself, it calls all the necessary
% subroutines that make LU decomposition work in our pseudocode
% implementation.
function [x] = Ludecomp(A,b,n,tol,x)
    o = zeros(n,1);
    s = zeros(n,1);
    er = 0;
    [A,er,o] = Decompose(A,n,tol,o,s,er);
    if(not (er==-1))
        [~,x] = Substitute(A,o,n,b,x);
    end
end