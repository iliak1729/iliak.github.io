%% Heat 2D
% This function provides us with our matrix and b vector for a two
% dimensional heat diffusion problem along with the x and y positions of
% all the grid points. We assume a boundary condition of T=0 everywhere.
function [A,b,x,y] = Heat2D(alpha,n,xmin,xmax,ymin,ymax)
    A = zeros(n*n);
    b = zeros(n*n,1);

    hx = (xmax-xmin)/n;
    hy = (ymax-ymin)/n;
    
    x = xmin:hx:xmax;
    y = ymin:hy:ymax;

    [x,y] = meshgrid(x,y);

    for i = 1:(n+1)
        for j = 1:(n+1)
            l = (j-1)*(n+1)+i;
            if(i== 1 || j == 1 || i == n+1 || j == n+1)
                A(l,l) = 1;
                b(l) = 0;
            else
                A(l,l-1) = 1/hx^2;
                A(l,l) = -2/hx^2;
                A(l,l+1) = 1/hx^2;
                A(l,l-n-1) = 1/hy^2;
                A(l,l) = A(l,l) - 2/hy^2;
                A(l,l+n+1) = 1/hy^2;

                b(l)=-alpha;
            end
        end
    end 
end