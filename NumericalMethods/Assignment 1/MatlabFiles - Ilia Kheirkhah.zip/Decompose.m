%% Decompose
% This function does the actual Doolittle decomposition algorithm, calling
% on pivot when necessary.
function [A,er,o] = Decompose(A,n,tol,o,s,er)
    for i = 1:n
        o(i)=i;
        s(i)=abs(A(i,1));
        for j = 2:n
            if(abs(A(i,j))>s(i))
                s(i)=abs(A(i,j));
            end
        end
    end

    for k = 1:(n-1)
        o = Pivot(A,o,s,n,k);
        if(abs(A(o(k),k)/s(o(k)))<tol)
            er = -1;
            disp(A(o(k),k)/s(o(k)));
            break;
        end

        for i =  (k+1):n
            factor = A(o(i),k)/A(o(k),k);
            A(o(i),k) = factor;
            for j = (k+1):n
                A(o(i),j) = A(o(i),j)-factor*A(o(k),j);
            end
        end
    end
    if(abs(A(o(k),k)/s(o(k)))<tol)
        er = -1;
        disp(A(o(k),k)/s(o(k)));
    end
    
end