% This function produces an initial guess for a given n,m and 
% converges with Newton's method.
% After that it applies analytic continuation to find a second guess and
% applies newton's method again to converge. After this, we loop through
% applying arc length continuation and the augmented Newton's method to
% converge on solutions until we reach either the maximum or minimum lambda
% value we define. The direction variable allows us to shift ds from
% positive to negative, allowing us to go in the forward and backward
% directions for a given solution branch.

function [norms,lambdas] = runner(N,n,m,lambdaMin,lambdaMax,direction)
%Do not alter
h = 1/(N-1);
x = 0:h:1;
y = 0:h:1;
[x,y] = meshgrid(x,y);


% Make initial guess
A = -0.1;
guess = A*sin(n*pi*x).*sin(m*pi*y);

l0 = (n^2+m^2)*pi^2+.3;
tol = 1e-6;

guess0 = zeros(N^2,1);
for i = 1:N
    for j = 1:N
        l = (j-1)*N+i;
        guess0(l) = guess(i,j);
    end
end


% Converge for u0
u0 = Newtons(l0,guess0,N,tol);
s0 = 0; % Definte as starting point
% Analytic Continuation for u1_0
dl = .1;
guess1 = analyticContinuation(u0,l0,N,dl);
l1 = l0 + dl;

% Converge for u1
u1 = Newtons(l1,guess1,N,tol);

% Find s1
summ = 0;
for i = 1:length(u1)
    summ = summ + (u1(i)-u0(i)).^2;
end
summ = summ + dl.^2;
ds = sqrt(summ);
s1 = s0+ds;

% Arc Length Continuation
tol = 1e-6;
ds = direction*.1;
[guess2,l2,s2] = arclengthContinuation(N,s1,s0,u1,u0,l1,l0,ds);

% Augmented Newtons Method to Converge
% disp(1);
[u2,~]= augmentedNewtons(N,s2,s1,l2,l1,guess2,u1,tol);

clear summ;
% Repeat until l = 60
norms = zeros(60,1);
lambdas = zeros(60,1);
count = 1;
while l2 < lambdaMax && l2 >lambdaMin
    u0 = u1;
    l0 = l1;
    s0 = s1;

    u1 = u2;
    l1 = l2;
    s1 = s2;
    [guess2,l2,s2] = arclengthContinuation(N,s1,s0,u1,u0,l1,l0,ds);
     disp(l2);
    

    [u2,l2] = augmentedNewtons(N,s2,s1,l2,l1,guess2,u1,tol);
    norms(count) = sqrt(sum(u2.^2));
    lambdas(count) = l2;
    count = count+1;
end

figure;
contourf(x,y,vecToArray(u2,N),20);
colorbar;
xlabel("X Position");
ylabel("Y Position");
title("n = "+num2str(n) + ", m = "+num2str(m)+" Solution Branch at " + ...
    "\lambda = "+num2str(l2));
end