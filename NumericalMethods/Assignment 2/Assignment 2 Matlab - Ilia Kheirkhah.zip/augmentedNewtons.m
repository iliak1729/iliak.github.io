% This is an application of Newton's method that takes advantage of arc
% length continuation.
function [u,l,J,delta] = augmentedNewtons(N,s2,s1,l2,l1,u2,u1,tol)
    
    error(1) = 10*tol;
    error(2) = 100*tol;
    e = 10*tol;
    [Rhat,Jhat] = getAugmentedJRhat(N,(s2-s1),l2,l1,u2,u1);
    count = 1;
    while e > tol
        Rhat = - Rhat;
        delta = Jhat\Rhat;
        sums = 0;
        for i = 1:length(delta)
            sums = sums + delta(i).^2;
        end
        e = sqrt(sums);
        error(count) = e;
        %disp(e);
%          if(count > 5)
%              if(error(count) - error(count-1) < tol)
%                  u = delta;
%                  
%                  J = Jhat;
%                  return;
%              end
%          end
        du = delta(1:N^2);
        dl = delta(end);
%         e = sum(du.^2);
        u2 = u2 + du;
        l2 = l2 + dl;
        
        % find updated s2
        du = u2-u1;
        sums = 0;
        for i = 1:length(du)
            sums = sums + du(i).^2;
        end
        sums = (l2-l1).^2+sums;
        s2 = s1 + sqrt(sums);
        [Rhat,Jhat] = getAugmentedJRhat(N,(s2-s1),l2,l1,u2,u1);
        count = count+1;
    end
    u = u2;
    l = l2;
    J = Jhat;
end