clear; clc; close all;
% This is the main code that drives the operations necessary to find the
% contour plots and norms that we need for this assignment. It involves
% running through all three branches in both the forward and backward
% directions to get a full norm plot.

%inputs
N = 30;
lambdaMax = 60;
lambdaMin = 5;

% Run
normFig = figure;
hold on;
xlim([0 60]);
xlabel('\lambda');
ylabel('||u||_2');
title('L-2 Norms of u for various \lambda');
legend;
axNorms = gca; % Graph for Norms

% n = 1, m = 1 branch
[N11L,L11L] = runner(N,1,1,lambdaMin,lambdaMax,-1);
disp("Branch 1a Done");
exportgraphics(gcf,"11Contour1.png");
[N11R,L11R] = runner(N,1,1,lambdaMin,lambdaMax,1);
disp("Branch 1b Done");
exportgraphics(gcf,"11Contour2.png");
[~,ind]=min(N11L);
posNorms11 = N11L(ind+1:end);
posLambdas11 = L11L(ind+1:end);
negNorms11 = [N11L(1:ind); N11R];
negLambdas11 = [L11L(1:ind); L11R];

Norms11 = [flip(posNorms11); -negNorms11];
lambdas11 = [flip(posLambdas11); negLambdas11];
plot(axNorms,lambdas11,Norms11,'b-','DisplayName','n = 1, m = 1 Solution Branch');

 % n = 1, m = 2 branch
[N12L,L12L] = runner(N,7,1,lambdaMin,lambdaMax,-1);
disp("Branch 2a Done");
exportgraphics(gcf,"12Contour1.png");
[N12R,L12R] = runner(N,1,2,lambdaMin,lambdaMax,1);
disp("Branch 2b Done");
exportgraphics(gcf,"12Contour2.png");

[~,ind] = min(N12L);
posNorms12 = N12L(ind:end);
negNorms12 = [(N12L(1:ind-1)); N12R];

posLambdas12 = L12L(ind:end);
negLambdas12 = [(N12L(1:ind-1));N12R];

plot(axNorms,posLambdas12,posNorms12,'c-','DisplayName','n = 1, m = 2 Solution Branch');
plot(axNorms,L12L,-N12L,'c-','HandleVisibility','off');

% n = 2, m = 1 branch
[N21L,L21L] = runner(N,2,1,lambdaMin,lambdaMax,-1);
disp("Branch 3a Done");
exportgraphics(gcf,"21Contour1.png");
[N21R,L21R] = runner(N,2,1,lambdaMin,lambdaMax,1);
disp("Branch 3b Done");
exportgraphics(gcf,"21Contour2.png");

[~,ind] = min(N21L);
posNorms21 = N21L(ind:end);
negNorms21 = [(N21L(1:ind-1)); N21R];

posLambdas21 = L21L(ind:end);
negLambdas21 = [(N21L(1:ind-1));N21R];

plot(axNorms,posLambdas21,posNorms21,'m--','DisplayName','n = 2, m = 1 Solution Branch');
plot(axNorms,L21L,-N21L,'m--','HandleVisibility','off');

plot(axNorms,[0 60], [0 0],'r-','DisplayName','Trivial Solution - u=0');

exportgraphics(normFig,"NormPlot.png");