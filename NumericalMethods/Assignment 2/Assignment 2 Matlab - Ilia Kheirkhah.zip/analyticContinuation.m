% Applies analytic continuation to produce an initial guess some distance,
% dl, from our solution u.
function [u0,J,drdl] = analyticContinuation(u,lambda,N,dl)
[~,J,drdl] = genJR(u,lambda,N);
dudl = J\drdl;
du = dudl*dl;
u0 = u + du;
end