% This function applies Arc Length Continuation to produce an initial guess
% that allows us to follow the solution curves.
function [u2_0,l2,s2] = arclengthContinuation(N,s1,s0,u1,u0,l1,l0,ds)
    [~,Jhat,dRhat] = getAugmentedJRhat(N,(s1-s0),l1,l0,u1,u0);
    dRhat = -dRhat;
    dvec = Jhat\dRhat;
    duds = dvec(1:N^2);
    dlds = dvec(end);

    du = duds * ds;
    dl = dlds * ds;

    u2_0 = u1 + du;
    l2 = l1 + dl;
    s2 = s1+ds;
end