% This function is used mostly for ease of reading. It takes in the
% necessary information to generate our augmented Jacobian and augmented
% Residual.
function [R_hat,J_hat,dR_hat] = getAugmentedJRhat(N,ds,l1,l0,u1,u0)
J_hat = zeros(N^2+1);
R_hat = zeros(N^2+1,1);
dR_hat = zeros(N^2+1,1);

% Get old values
[R,J] = genJR(u1,l1,N);

% Fill in appropriately
J_hat(1:N^2,1:N^2) = J;
R_hat(1:N^2) = R;

% Fill dR_hat %%%%%%%%
dR_hat(end) = 2*(ds);

%Fill R_hat %%%%%%%%

sum = 0;
% Calculate 2-Norm of u1-u0
for i = 1:length(u1)
    sum = sum + (u1(i)-u0(i)).^2;
end

eta = (ds).^2-sum-(l1-l0).^2;
R_hat(end) =  eta;
% disp("eta="+num2str(eta));
% Fill J_hat %%%%%%%
detadu = zeros(1,N^2);
dRdl = zeros(N^2,1);

for i = 1:N
    for j = 1:N
        l = (j-1)*N+i;
        detadu (l) = -2*(u1(l)-u0(l));
        if(i== 1 || j == 1 || i == N || j == N)
            dRdl(l) = 0;
        else
            dRdl(l) = u1(l) * (1+u1(l));
        end
    end
end

detadl = -2*(l1-l0);
J_hat(1:N^2,end) = dRdl;
J_hat(end,1:N^2) = detadu;
J_hat(end,end) = detadl;
end