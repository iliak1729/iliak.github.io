function [R,J,drdl] = genJR(u,lambda,N)
%This function takes in our current u and lambda values and returns the
%R vector and the associated Jacobian for an NxN case of the differential
%equation provided in Assignment 2
%   This is purely a helper function that makes the code slightly more
%   readable. It is used to generate our R vector and the Jacobian which is
%   the derivative of this vector. For testing purposes, I allowed for
%   variations in the dimension of the matrix.

if(length(u) ~= N^2)
    R = -1;
    J = -1;
    return;
end

h = 1/(N-1);
% Generate
R = zeros(N^2,1);
J = zeros(N^2);
drdl = zeros(N^2,1);

for i = 1:N
    for j = 1:N
        l = (j-1)*N+i;
        drdl(l) = u(l)*(1+u(l));
        if(i== 1 || j == 1 || i == N || j == N)
            J(l,l) = 1;
            R(l) = u(l);
        else
            R(l) = (u(l-1)-2*u(l)+u(l+1))/h^2 +...
                (u(l-N)-2*u(l)+u(l+N))/h^2 + ...
                lambda*u(l)*(1+u(l));

            J(l,l)=-4/h^2 + lambda*(1+2*u(l));
            J(l,l-1) = 1/h^2;
            J(l,l+1) = 1/h^2;
            J(l,l+N) = 1/h^2;
            J(l,l-N) = 1/h^2;
        end
    end
end

end