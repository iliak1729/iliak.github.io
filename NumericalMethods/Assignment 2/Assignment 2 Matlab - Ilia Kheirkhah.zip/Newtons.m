% This is an application of Newton's method to converge to a solution for a
% given initial guess u to some tolerance tol.
function [u,error,J] = Newtons(lambda,u,N,tol)
    
    error = 10*tol;
    e = 10 * tol;
    count = 1;
    [R,J] = genJR(u,lambda,N);
    while e > tol
        du = J\(-R);
        sum = 0;
        for i = 1:length(du)
            sum = sum + du(i).^2;
        end
        e = sqrt(sum);
        error(count) = e;
        count = count+1;
        u = u + du;
        [R,J] = genJR(u,lambda,N);
    end
end