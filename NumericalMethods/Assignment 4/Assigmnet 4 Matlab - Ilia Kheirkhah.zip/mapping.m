% This is a simple mapping from the unit domain to the element domain.
function [x, dxdc] = mapping(x1,x2,chi)
    
    [val1, dval1] = basisLocal(1,chi);
    [val2,dval2] = basisLocal(2,chi);
    x = x1*val1 + x2*val2;
    dxdc = x1*dval1 + x2*dval2;
end