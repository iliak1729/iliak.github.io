% This function is returns the value of the global basis function at a 
% given point
% The i variable selects which basis function we want. We then go through
% xset and determine the bounds on the elemnt we are in to determine the
% mapping from the true element to the unit element. We then map our x
% location to the proper location in the unit element and find the value.
function [val,x0,x1,x2,chi,type]= basisGlobal(i,xset,x)
    if(i <= length(xset) && i >= 1) % Determine Bounds
        x1 = xset(i);
        if(i ~= 1)
            x0 = xset(i-1);
        else
            x0 = xset(1);
        end
        if(i~=length(xset))
            x2 = xset(i+1);
        else
            x2 = xset(end);
        end
    else % Out of bound error catch
        val = -1;
        x0 = -1;
        x1 = -1;
        x2 = -1;
        chi = -1;
        type =-1;
        return;
    end
    
    if(x <= x0 || x >= x2) % Outside of this range returns 0
        val =0;
        chi = -2;
        type = -2;
    else
        if(x < x1) % Positive slope case
            chi = x - ((x0+x1)/2);
            chi = chi/((x1-x0)/2);
            chi = round(chi*100000)/100000; % Fix floating point jazz
            val = basisLocal(2,chi);
            type = 2;
        else % Negative Slope Case
            chi = x - ((x1+x2)/2);
            chi = chi/((x2-x1)/2);
            chi = round(chi*100000)/100000;
            val = basisLocal(1,chi);
            type = 1;
        end
    end
end
