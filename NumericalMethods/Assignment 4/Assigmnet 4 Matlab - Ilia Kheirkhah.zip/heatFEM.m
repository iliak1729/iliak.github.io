function [Ti,plotY] = heatFEM(Nel,alpha,plotset)
% Inputs
N = Nel;

% Other Parameters
Nnodes = N+1; %Number of Points

xset = linspace(0,1,Nnodes); % Evenly Spaced Points

gaussPoints = [-sqrt(3/5) 0 sqrt(3/5)];
gaussWeights = [5/9 8/9 5/9];

% Allocate Space
A = zeros(Nnodes);
b = zeros(Nnodes,1);

% Center Elements
for k = 1:N % Loop Through Elements
    Aloc = zeros(2); % Local 2x2 A matrix
    bloc = zeros(2,1); % Local b vector
    x1 = xset(k); % Left Point
    x2 = xset(k+1); % Right Point

    for i = 1:2 % Loop through First Local Basis Functions 
        for j = 1:2 % Loop Through Second Local Basis Function
            % Populate Variables
            [phii, dphiidchi] = basisLocal(i,gaussPoints); % dphii/dchi
            [~, dphijdchi] = basisLocal(j,gaussPoints); % dphij/dchi

            [~, dxdc] = mapping(x1,x2,gaussPoints); % Mapping Jacobian
            
            % Generate Local A matrix
            for g = 1:3 %sum 
                Aloc(i,j) = Aloc(i,j) + gaussWeights(g)*dphiidchi(g)...
                    *dphijdchi(g)/dxdc(g);
            end

            % Generate Local b vector
            bloc(i) = sum(gaussWeights.*phii.*alpha.*dxdc);
        end
    end
    % Place local information into global matrix and vector
    A(k:k+1,k:k+1) =  A(k:k+1,k:k+1) + Aloc;
    b(k:k+1) = b(k:k+1) + bloc;
end

% Set Boundary Conditions
% Override first row
A(1,:) = 0; 
A(1,1) = 1;
% Override last row
A(Nnodes,:) = 0;
A(Nnodes,Nnodes) = 1;

% Fix Vector
b(1) = 0;
b(Nnodes) = 0;

% Find Solution
Ti = A\b;

% Now that solution is found, apply approximation to say u = sum(Ti*phi(i))
% This last section is just to make plotting and processing easier
plotY = zeros(size(plotset));
for i = 1:length(plotset)
    xCurr = plotset(i);
    val = 0;
    
    for j = 1:length(xset)
        Tcurr = Ti(j);
        val = val + Tcurr*basisGlobal(j,xset,xCurr);
    end
    plotY(i) = val;
end

end