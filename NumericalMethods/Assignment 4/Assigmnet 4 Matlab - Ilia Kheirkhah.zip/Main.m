clear; clc; close all;
% Compare Parameters
alphaSet = [1,5,25,50,100];
Nset = [5,10,25,50,100];


for i=1:length(Nset)
    figure;
    hold on;
    N = Nset(i);
    xset = linspace(0,1,N+1);
    errors = zeros(N,1);
    title("N_e = "+num2str(N))
    for j = 1:length(alphaSet)
        alpha = alphaSet(j);
        [Ti, plotY] = heatFEM(N,alpha,xset);
        plot(xset,plotY,'-','DisplayName',"\alpha = "+num2str(alpha))
    end
    legend;
    xlabel("x");
    ylabel("T");
    exportgraphics(gcf,"N = "+num2str(N)+" Vary Alpha.png")
end

figure;
hold on;
alpha = 5;

title("\alpha = "+num2str(alpha))
for j = 1:length(Nset)
    N = Nset(j);
    xset = linspace(0,1,N+1);
    errors = zeros(N,1);
    [Ti, plotY] = heatFEM(N,alpha,xset);
    plot(xset,plotY,'-','DisplayName',"N = "+num2str(N))
end
legend;
exportgraphics(gcf,"alpha = 5, Vary N for Error.png");

% Error
figure;
hold on;
alpha = 5;

title("\alpha = "+num2str(alpha))
for j = 1:length(Nset)
    N = Nset(j);
    xset = linspace(0,1,N+1);
    errors = zeros(N,1);
    [Ti, plotY] = heatFEM(N,alpha,xset);
    plot(xset,plotY,'-','DisplayName',"N = "+num2str(N))
end
legend;
plotset = linspace(0,1,1000);
theoryY = -alpha*plotset.^2/2+alpha*plotset/2;
plot(plotset,theoryY,'k-','DisplayName',"Theory Curve");
exportgraphics(gcf,"alpha = 5, Vary N for Error with theory.png");

% Error
alphaSet = [1,5,25,50,100];
Nset = 5:5:1000;
errors = zeros(length(alphaSet),length(Nset));
figure;
hold on;
for i = 1:length(alphaSet)
    alpha = alphaSet(i);
    theoryFunc = @(x) (-alpha*x.^2./2+alpha.*x./2);
    for j = 1:length(Nset)
        N = Nset(i);
        xset = linspace(0,1,N+1);
        [Ti,plotY] = heatFEM(N,alpha,xset);
        errVec = plotY-theoryFunc(xset);
        errors(i,j) = sqrt(sum(errVec.^2));
    end
    plot(Nset,errors(i,:),'-',"DisplayName","\alpha = "+num2str(alpha));
end
title("Error Plots");
xlabel("Number of Elements");
ylabel("Error");
legend;
exportgraphics(gcf,"Error.png")



