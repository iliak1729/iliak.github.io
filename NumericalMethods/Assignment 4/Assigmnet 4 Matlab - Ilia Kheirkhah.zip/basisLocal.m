% This function evaluates the local basis function on the unit element
% The type is the local type of the linear basis
% 1 represents the downwards sloped basis
% 2 represents the upwards sloped basis
% The value of chi determines the value. If it is from -1 to 1, the output
% is determined using the type of basis function we select. If it is out of
% that range, we return 0.
function [val, dval] = basisLocal(type,chi)
    val = zeros(size(chi));
    dval = zeros(size(chi));
    for i = 1:length(chi)
        if(type == 1)
            val(i) = .5*(1-chi(i));
            dval(i) = -.5;
        else
            val(i) = .5*(1+chi(i));
            dval(i) = .5;
        end
        % disp(abs(chi(i)))
        if (abs(chi(i)) > 1)
            val(i) = 0;
            dval(i) = 0;
        end
    end
end
