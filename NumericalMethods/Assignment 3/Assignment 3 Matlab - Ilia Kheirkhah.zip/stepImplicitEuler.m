% To run this function, pass in all the a,b,c,d,p,q parameters and an
% initial condition (2x1 vector) x0 and a step size h. This program will
% take one step of Implicit Euler.
function [x1,J,R] = stepImplicitEuler(a,b,c,d,p,q,x0,h,tol)
if(length(x0) ~= 2)
    disp("Initial Condition must be a 2x1 Vector");
    return
end

J = zeros(2);
R = zeros(2,1);

error = 2*tol;
x1 = zeros(2,1);
x1(1) = x0(1);
x1(2) = x0(2);

while error > tol
    % Fill in J matrix
    J(1,1) = 1 - h*(a-b*x1(2))+2*h*p*x1(1);
    J(1,2) = h*b*x1(1);
    J(2,1) = -h * c * x1(2);
    J(2,2) = 1 - h*(c*x1(1)-d) + 2*h*q*x1(2);

    % Fill in R Vector
    R(1) = x1(1) - h*(a-b*x1(2))*x1(1) + h*p*x1(1).^2 - x0(1);
    R(2) = x1(2) - h*(c*x1(1)-d)*x1(2) + h*q*x1(2).^2 - x0(2);

    % Solve J(dx) = -R
    dx = J\(-R);

    % Find Error
    error = sqrt(sum(dx.^2));

    % Alter x1
    x1 = x1 + dx;
end
end

