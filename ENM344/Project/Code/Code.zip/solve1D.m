function [name,xset,T] = solve1D(N,alpha)
    cd C:\Users\ik465\Desktop\School\'Year 4 Sem 1'\'ENM 3440'\Projec;
    % Solve the heat equaton
    domainLength = 1;
    
    tic;
    xset = linspace(0,domainLength,N);
    dx = xset(2)-xset(1);
    
    % Make A and B matrix;
    Npoints = N;
    A = zeros(Npoints);
    b = zeros(Npoints,1);
    
    for i = 1:N
            l = i;
            if(i == 1 || i == N)
                A(l,l) = 1;
                b(l) = 0;
            else
                A(l,l) = -2/dx^2;
                A(l,l-1) = 1/dx^2;
                A(l,l+1) = 1/dx^2;
                b(l) = -alpha;
            end
    end
    T = A\b;
    output = zeros(Npoints,3);
    for i = 1:N
            l = i;
            output(l,1) = xset(i);
            output(l,2) = T(l);
            output(l,3) = alpha;
    end
    name = "heatData1D - "+num2str(N)+"- a = "+num2str(alpha)+".csv";
    % writematrix(output,name);
    t = toc;
    % Plot
    %figure;
    %plot(xset,T);

end