import deepxde as dde
import matplotlib.pyplot as plt
import numpy as np
import random
# Import tf if using backend tensorflow.compat.v1 or tensorflow
from deepxde.backend import tf
# Import torch if using backend pytorch
# import torch
# Import paddle if using backend paddle
# import paddle
import matlab.engine
import time

eng = matlab.engine.start_matlab()
qset = np.linspace(1,100,50)
errorSet = np.zeros(np.size(qset))
errorSetMatlab = np.zeros(np.size(qset))
for i in range(len(qset)):
    q = qset[i]
    print("q = "+str(q))
    def pde(x, y):
        dy_xx = dde.grad.hessian(y, x)
        # Use tf.sin for backend tensorflow.compat.v1 or tensorflow
        return dy_xx + q
        # Use torch.sin for backend pytorch
        # return -dy_xx - np.pi ** 2 * torch.sin(np.pi * x)
        # Use paddle.sin for backend paddle
        # return -dy_xx - np.pi ** 2 * paddle.sin(np.pi * x)



    fileName, xset, Tmatlab = eng.solve1D(99,q,nargout = 3)
    Tmatlab = np.array(Tmatlab)
    Tmatlab = Tmatlab.tolist()
    #print(Tmatlab)
    #print("=================================================")
    #print(fileName)
    #eng.quit()

    def boundary(x, on_boundary):
        return on_boundary


    def func(x):
        #return -q*x**2/2 + q*x/2
        return x*0


    geom = dde.geometry.Interval(0, 1)
    bc = dde.icbc.DirichletBC(geom, func, boundary)
    data = dde.data.PDE(geom, pde, bc, 16, 2, solution=func, num_test=100)

    layer_size = [1] + [50] * 3 + [1]
    activation = "tanh"
    initializer = "Glorot uniform"
    net = dde.nn.FNN(layer_size, activation, initializer)

    model = dde.Model(data, net)
    model.compile("adam", lr=0.001, metrics=["l2 relative error"])

    losshistory, train_state = model.train(iterations=10000)
    
    # Error Calculation Section
    Ntest = 100
    xtest = np.array(xset)
    xtest = xtest.tolist()
    # print(xtest)
    # print(np.size(xtest))
    TsetReal = []
    TsetPred = []
    error = 0
    errorMatlab = 0
    for k in range(len(xtest)):
        #print(k)
        xin = float(xtest[k][1])
        #print(xin)
        Tactual = -q*xin**2/2 + q*xin/2
        #TsetReal.append(Tactual)
        Tpred = float(model.predict(np.array([[xin]])))
        #print(Tpred)
        #TsetPred.append(Tpred)
        error = error + (Tpred-Tactual)**2
        errorMatlab = errorMatlab + (float(Tmatlab[1][k])-float(Tactual))**2
    #plt.figure()
    #plt.plot(xtest,TsetReal)
    #plt.plot(xtest,TsetPred)
    #plt.show()
    errorSet[i] = np.sqrt(error) # Use L2 Norm to calculate error
    errorSetMatlab[i] = np.sqrt(errorMatlab) # Same for Matlab
    
    # Optional: Save the model during training.
    # checkpointer = dde.callbacks.ModelCheckpoint(
    #     "model/model", verbose=1, save_better_only=True
    # )
    # Optional: Save the movie of the network solution during training.
    # ImageMagick (https://imagemagick.org/) is required to generate the movie.
    # movie = dde.callbacks.MovieDumper(
    #     "model/movie", [-1], [1], period=100, save_spectrum=True, y_reference=func
    # )
    # losshistory, train_state = model.train(iterations=10000, callbacks=[checkpointer, movie])

    # dde.saveplot(losshistory, train_state, issave=True, isplot=True)

    # Optional: Restore the saved model with the smallest training loss
    # model.restore(f"model/model-{train_state.best_step}.ckpt", verbose=1)
    # Plot PDE residual
    # x = geom.uniform_points(1000, True)
    # y = model.predict(x, operator=pde)
    # plt.figure()
    # plt.plot(x, y)
    # plt.xlabel("x")
    # plt.ylabel("PDE residual")
    # plt.show()

# Plot Error
plt.figure()
plt.plot(qset,errorSet)
plt.xlabel("q")
plt.ylabel("EL2 Error")
plt.grid(True)
plt.title("Error Scaling")
plt.show()

# Calcualte time to evaluate
start_time = time.time()
timeset = []
Nset = np.linspace(1,2000,50)

for j in range(len(Nset)):
    start_time = time.time()
    for i in range(int(Nset[j])):
        y_pred = model.predict(np.array([[random.random()]]))
    timeset.append(time.time() - start_time)
    print(j)

plt.figure()
plt.plot(Nset,timeset)
plt.xlabel("Number of Points")
plt.ylabel("Evaluation Time (s)")
plt.grid(True)
plt.title("Time Scaling")
plt.show()
